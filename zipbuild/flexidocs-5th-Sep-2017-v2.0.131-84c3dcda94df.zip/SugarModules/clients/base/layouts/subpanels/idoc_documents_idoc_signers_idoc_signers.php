<?php
// created: 2015-07-23 11:01:30
$viewdefs['idoc_signers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_IDOC_DOCUMENTS_IDOC_SIGNERS_FROM_IDOC_DOCUMENTS_TITLE',
  'context' => 
  array (
    'link' => 'idoc_documents_idoc_signers',
  ),
);

$viewdefs['idoc_signers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_IDOC_DOCUMENTS_IDOC_SIGNERS_FROM_IDOC_DOCUMENTS_TITLE',
  'context' => 
  array (
    'link' => 'idoc_documents_idoc_signers',
  ),
);

$viewdefs['idoc_signers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_IDOC_DOCUMENTS_IDOC_SIGNERS_FROM_IDOC_DOCUMENTS_TITLE',
  'context' => 
  array (
    'link' => 'idoc_documents_idoc_signers',
  ),
);

$viewdefs['idoc_signers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_IDOC_DOCUMENTS_IDOC_SIGNERS_FROM_IDOC_DOCUMENTS_TITLE',
  'context' => 
  array (
    'link' => 'idoc_documents_idoc_signers',
  ),
);

$viewdefs['idoc_signers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_IDOC_DOCUMENTS_IDOC_SIGNERS_FROM_IDOC_DOCUMENTS_TITLE',
  'context' => 
  array (
    'link' => 'idoc_documents_idoc_signers',
  ),
);

$viewdefs['idoc_signers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_IDOC_DOCUMENTS_IDOC_SIGNERS_FROM_IDOC_DOCUMENTS_TITLE',
  'context' => 
  array (
    'link' => 'idoc_documents_idoc_signers',
  ),
);

$viewdefs['idoc_signers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_IDOC_DOCUMENTS_IDOC_SIGNERS_FROM_IDOC_DOCUMENTS_TITLE',
  'context' => 
  array (
    'link' => 'idoc_documents_idoc_signers',
  ),
);

$viewdefs['idoc_signers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_IDOC_DOCUMENTS_IDOC_SIGNERS_FROM_IDOC_DOCUMENTS_TITLE',
  'context' => 
  array (
    'link' => 'idoc_documents_idoc_signers',
  ),
);

$viewdefs['idoc_signers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_IDOC_DOCUMENTS_IDOC_SIGNERS_FROM_IDOC_DOCUMENTS_TITLE',
  'context' => 
  array (
    'link' => 'idoc_documents_idoc_signers',
  ),
);