<?php

$mod_strings['LBL_BLOCKEDITFIELD'] = 'Block Edit Text';
$mod_strings['LBL_BLOCKEDITFIELD_FORMAT_HELP'] = '';

$mod_strings['LBL_BLOCKEDITFIELD_BACKCOLOR'] = 'Background Color';
$mod_strings['LBL_BLOCKEDITFIELD_TEXTCOLOR'] = 'Text Color';
