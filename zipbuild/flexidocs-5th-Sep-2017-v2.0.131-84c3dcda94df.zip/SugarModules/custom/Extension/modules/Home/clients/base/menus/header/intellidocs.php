<?php

$viewdefs[$module_name]['base']['menu']['header'][] = array(
    'route' => '#Home/layout/send-letters',
    'label' => 'Send Letters',
    'icon' => 'fa fa-book',
);

?>