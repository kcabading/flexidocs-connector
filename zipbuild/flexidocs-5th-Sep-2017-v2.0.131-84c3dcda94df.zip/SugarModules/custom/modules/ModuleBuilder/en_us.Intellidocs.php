<?php

$mod_strings['fieldTypes']['Blockeditfield'] = 'Block Edit Field';

