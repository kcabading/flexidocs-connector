<?php
$mod_strings['LBL_INTELLIDOCS_DEFAULT_SUBJECT'] = 'New Document for Signing: ';