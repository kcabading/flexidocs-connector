<?php
// CRM Accelerator Admin strings
$mod_strings['LBL_INTELLIDOCS_TITLE'] = 'Flexidocs for SugarCRM';
$mod_strings['LBL_INTELLIDOCS_DESC'] = 'Allows you to manually update local documents from your Flexidocs account.';
$mod_strings['LBL_INTELLIDOCS_CONFIG'] = 'Sync Flexidocs';
$mod_strings['LBL_INTELLIDOCS_CONFIG_DESC'] = 'Manually update documents';
$mod_strings['LBL_INTELLIDOCS_PLATFORM'] = 'Open Flexidocs Platform';
$mod_strings['LBL_INTELLIDOCS_PLATFORM_DESC'] = 'Go to the Flexidocs Platform and mananage your documents and electronic signing';
$mod_strings['LBL_FLEXIDOCS_TEMPLATES'] = 'Manage FlexiDocs Templates';
$mod_strings['LBL_FLEXIDOCS_TEMPLATES_DESC'] = 'Allows you to controls the visibility and manage other options of your flexidocs templates';
?>
