<?php
 // created: 2015-08-19 15:36:35
$layout_defs["idoc_documents"]["subpanel_setup"]['idoc_documents_idoc_signers'] = array (
  'order' => 100,
  'module' => 'idoc_signers',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_IDOC_DOCUMENTS_IDOC_SIGNERS_FROM_IDOC_SIGNERS_TITLE',
  'get_subpanel_data' => 'idoc_documents_idoc_signers',
);
