<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Team',
  'LBL_TEAMS' => 'Team',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'Tildelt bruger-id',
  'LBL_ASSIGNED_TO_NAME' => 'Tildelt til',
  'LBL_TAGS_LINK' => 'Tags',
  'LBL_TAGS' => 'Tags',
  'LBL_ID' => 'Id',
  'LBL_DATE_ENTERED' => 'Oprettet den',
  'LBL_DATE_MODIFIED' => 'Ændret den',
  'LBL_MODIFIED' => 'Ændret af',
  'LBL_MODIFIED_ID' => 'Ændret af id',
  'LBL_MODIFIED_NAME' => 'Ændret af navn',
  'LBL_CREATED' => 'Oprettet af',
  'LBL_CREATED_ID' => 'Oprettet af id',
  'LBL_DOC_OWNER' => 'Dokument ejer',
  'LBL_USER_FAVORITES' => 'Brugernes favorit',
  'LBL_DESCRIPTION' => 'Beskrivelse',
  'LBL_DELETED' => 'Slettet',
  'LBL_NAME' => 'Navn',
  'LBL_CREATED_USER' => 'Oprettet af bruger',
  'LBL_MODIFIED_USER' => 'Ændret af bruger',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_EDIT_BUTTON' => 'Rediger',
  'LBL_REMOVE' => 'Fjern',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Ændret af navn:',
  'LBL_LIST_FORM_TITLE' => 'Flexidocs Templates Liste',
  'LBL_MODULE_NAME' => 'Flexidocs Templates',
  'LBL_MODULE_TITLE' => 'Flexidocs Templates',
  'LBL_MODULE_NAME_SINGULAR' => 'Flexidocs Template',
  'LBL_HOMEPAGE_TITLE' => 'Min Flexidocs Templates',
  'LNK_NEW_RECORD' => 'Opret Flexidocs Template',
  'LNK_LIST' => 'Vis Flexidocs Templates',
  'LNK_IMPORT_IDOC_TEMPLATES' => 'Import Flexidocs Template',
  'LBL_SEARCH_FORM_TITLE' => 'Søg Flexidocs Template',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Vis historik',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteter',
  'LBL_IDOC_TEMPLATES_SUBPANEL_TITLE' => 'Flexidocs Templates',
  'LBL_NEW_FORM_TITLE' => 'Ny Flexidocs Template',
  'LNK_IMPORT_VCARD' => 'Import Flexidocs Template vCard',
  'LBL_IMPORT' => 'Import Flexidocs Templates',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Flexidocs Template record by importing a vCard from your file system.',
  'LBL_PARENT_MODULE' => 'Parent Module',
  'LBL_ENABLE_MAIL' => 'Enable Mail',
  'LBL_FIELD_MAP' => 'Field Map',
  'LBL_FILE_TYPE' => 'File Type',
  'LBL_FILE_NAME' => 'File Name',
  'LBL_NO_OF_SIGNERS' => 'No of Signers',
  'LBL_ALLOW_EMAIL' => 'Allow Email',
  'LBL_ALLOW_DOWNLOAD' => 'Allow Download',
  'LBL_OUTPUT_FORMAT_PDF' => 'Allow PDF Download',
  'LBL_OUTPUT_FORMAT_ORIG' => 'Allow Original File Download',
  'LBL_STATUS' => 'Status',
);