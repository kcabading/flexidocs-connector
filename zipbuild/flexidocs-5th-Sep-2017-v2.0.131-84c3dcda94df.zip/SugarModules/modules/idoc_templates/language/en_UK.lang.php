<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Teams',
  'LBL_TEAMS' => 'Teams',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_TAGS_LINK' => 'Tags',
  'LBL_TAGS' => 'Tags',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_DOC_OWNER' => 'Document Owner',
  'LBL_USER_FAVORITES' => 'Users Who Favourite',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Name',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_LIST_NAME' => 'Name',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_REMOVE' => 'Remove',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modified By Name',
  'LBL_LIST_FORM_TITLE' => 'Flexidocs Templates List',
  'LBL_MODULE_NAME' => 'Flexidocs Templates',
  'LBL_MODULE_TITLE' => 'Flexidocs Templates',
  'LBL_MODULE_NAME_SINGULAR' => 'Flexidocs Template',
  'LBL_HOMEPAGE_TITLE' => 'My Flexidocs Templates',
  'LNK_NEW_RECORD' => 'Create Flexidocs Template',
  'LNK_LIST' => 'View Flexidocs Templates',
  'LNK_IMPORT_IDOC_TEMPLATES' => 'Import Flexidocs Template',
  'LBL_SEARCH_FORM_TITLE' => 'Search Flexidocs Template',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_IDOC_TEMPLATES_SUBPANEL_TITLE' => 'Flexidocs Templates',
  'LBL_NEW_FORM_TITLE' => 'New Flexidocs Template',
  'LNK_IMPORT_VCARD' => 'Import Flexidocs Template vCard',
  'LBL_IMPORT' => 'Import Flexidocs Templates',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Flexidocs Template record by importing a vCard from your file system.',
  'LBL_PARENT_MODULE' => 'Parent Module',
  'LBL_ENABLE_MAIL' => 'Enable Mail',
  'LBL_FIELD_MAP' => 'Field Map',
  'LBL_FILE_TYPE' => 'File Type',
  'LBL_FILE_NAME' => 'File Name',
  'LBL_NO_OF_SIGNERS' => 'No of Signers',
  'LBL_ALLOW_EMAIL' => 'Allow Email',
  'LBL_ALLOW_DOWNLOAD' => 'Allow Download',
  'LBL_OUTPUT_FORMAT_PDF' => 'Allow PDF Download',
  'LBL_OUTPUT_FORMAT_ORIG' => 'Allow Original File Download',
  'LBL_STATUS' => 'Status',
);